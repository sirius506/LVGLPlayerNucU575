Contents of this under this directory need to be copied onto SD card.

Please note that following directories are empty and you need to
download necessary files.

doom1-music:
  Please download FLAC format 'DOOM/Ultimate DOOM'  music pack
  from http://sc55.duke4.net/games.php#

doom2-music:
  Please download FLAC format 'DOOM II V1.2'  music pack
  from http://sc55.duke4.net/games.php#

tnt-music:
  Please download FLAC format 'Final DOOM/TNT' music pack
  from http://sc55.duke4.net/games.php#

OscMusic:
  Please donwload your purchsesed WAV files.
  Ref. https://oscilloscopemusic.com/watch/oscilloscope_music.

N-SPHERES:
  Please donwload your purchsesed WAV files.
  Ref. https://oscilloscopemusic.com/watch/n-spheres
