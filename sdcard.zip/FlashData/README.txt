This directory contains minimum necessary files to start LVGLPlayer.

Files under this directory (except README.txt and OFL.txt) are need to be
copied on the QSPI Flash by 'Doom Player' application.

* default.cfg, disco-doom.cfg
  DOOM configuration files.

* doom1-music.cfg, doom2-music.cfg, tnt-music.cfg
  These three files are music pack configuration files found at
  https://github.com/chocolate-doom/music-packs

* AlbumFont.ttf is TrueType Font file used in 'Bluetooth Player' application.
  It is used to display music title and artist name.
  This file is downloaded from https://fonts.google.com/noto/specimen/Noto+Sans+JP and
  it is originally named as 'NotoSansJP-Regular.ttf'.
  You can download your favorite TrueType font instead of 'NotoSansJP-Regular.ttf',
  but need to rename it as 'AlbumFont.ttf'.

* Doom*.bin
  These files are Icon image files used in Music Player.
  Original PNG image data is available from following URLs.

  https://iconarchive.com/show/mega-games-pack-26-icons-by-3xhumed.1.html 
  https://iconarchive.com/show/games-icons-by-skullboarder.html
  https://iconarchive.com/show/mega-games-pack-04-icons-by-3xhumed.html
